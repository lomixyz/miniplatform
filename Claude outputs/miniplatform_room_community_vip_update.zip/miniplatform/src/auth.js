const { levelFromXp } = require('./level');
const { dailyXpStatus } = require('./xp');
const db = require('./db');

// A purchased Color Shop color is locked in (can't be reset/replaced) for
// this many days from the purchase timestamp — see routes/colors.js.
const COLOR_LOCK_DAYS = 30;

function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: 'Not logged in' });
  next();
}

// requireFlag('staff') passes if the user has is_staff; requireFlag('staff','global_admin')
// passes if the user has EITHER flag (i.e. any of the listed flags is truthy).
const FLAG_MAP = {
  staff: 'is_staff', global_admin: 'is_global_admin', mentor: 'is_mentor', merchant: 'is_merchant',
  exec_board: 'is_exec_board', country_rep: 'is_country_rep', elite: 'is_elite',
};
function requireFlag(...flags) {
  return (req, res, next) => {
    const u = req.session.user;
    if (!u) return res.status(401).json({ error: 'Not logged in' });
    const ok = flags.some((f) => !!u[FLAG_MAP[f]]);
    if (!ok) return res.status(403).json({ error: 'Forbidden: insufficient privileges' });
    next();
  };
}

// Returns an ISO timestamp string while a purchased username color is still
// locked (< COLOR_LOCK_DAYS since it was bought), or null once it's free to
// change again / was never bought. Purely a read — routes/colors.js does the
// actual enforcement, this just lets the client show "locked until X".
function colorLockedUntil(boughtAt) {
  if (!boughtAt) return null;
  const boughtMs = new Date(boughtAt.replace(' ', 'T') + 'Z').getTime();
  if (!Number.isFinite(boughtMs)) return null;
  const unlockMs = boughtMs + COLOR_LOCK_DAYS * 24 * 60 * 60 * 1000;
  return unlockMs > Date.now() ? new Date(unlockMs).toISOString() : null;
}

// Shape a raw DB user row into what's safe/useful to send to the client,
// including the derived level/progress from their stored xp.
function publicUser(row) {
  if (!row) return null;
  const { level, xpIntoLevel, xpForNextLevel } = levelFromXp(row.xp || 0);
  // Badge Store (Explore -> Badge Panel to equip) — resolved here (not just
  // the bare id) so the profile card can show it without a second round trip.
  const equippedBadge = row.equipped_badge_id
    ? db.prepare('SELECT id, name, emoji FROM badges_catalog WHERE id = ?').get(row.equipped_badge_id)
    : null;
  return {
    id: row.id,
    username: row.username,
    is_staff: !!row.is_staff,
    is_global_admin: !!row.is_global_admin,
    is_mentor: !!row.is_mentor,
    is_merchant: !!row.is_merchant,
    is_exec_board: !!row.is_exec_board,
    is_country_rep: !!row.is_country_rep,
    is_elite: !!row.is_elite,
    // VIP Subscription (rainbow username) — only true while BOTH the flag is
    // set AND it hasn't run past vip_rainbow_expires_at yet, same
    // "server-trusted snapshot" pattern used elsewhere in this function
    // (e.g. username_color_locked_until below) rather than a separate sweep
    // job. See usernameStyleAttr() in public/app.js for why this one
    // overrides every other color, including Staff's.
    is_vip_rainbow: !!row.is_vip_rainbow && (!row.vip_rainbow_expires_at || new Date(row.vip_rainbow_expires_at) > new Date()),
    vip_rainbow_expires_at: row.vip_rainbow_expires_at || null,
    coins: row.coins,
    xp: row.xp || 0,
    level,
    xpIntoLevel,
    xpForNextLevel,
    bio: row.bio || '',
    uno_wins: row.uno_wins || 0,
    total_spent: row.total_spent || 0,
    gifts_sent_count: row.gifts_sent_count || 0,
    username_color: row.username_color || null,
    username_gradient: row.username_gradient || null,
    avatar_frame_color: row.avatar_frame_color || null,
    avatar_pet: row.avatar_pet || null,
    avatar_scene: row.avatar_scene || null,
    country: row.country || null,
    email: row.email || null,
    gender: row.gender || null,
    referrer_user_id: row.referrer_user_id || null,
    created_at: row.created_at || null,
    status: row.status === 'away' || row.status === 'busy' ? row.status : 'online',
    username_color_locked_until: colorLockedUntil(row.username_color_bought_at),
    equipped_badge: equippedBadge || null,
    active_color_key: row.active_color_key || null,
    avatar_photo_url: row.avatar_photo_url || null,
    cover_photo_url: row.cover_photo_url || null,
    dailyXp: dailyXpStatus(row), // { cap, earnedToday, remainingToday, resetsAt } — Sudan-day xp-earn limit, shown on the Level screen
  };
}

module.exports = { requireLogin, requireFlag, publicUser, FLAG_MAP, COLOR_LOCK_DAYS, colorLockedUntil };
